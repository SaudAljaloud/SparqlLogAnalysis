java -Xmx6000m -Djava.util.logging.config.file=etc/jdk14.properties -cp target/SparqlLogAnalysis.jena-0.0.1.jar:target/dependency/* main1.Java.saud.sparqlLogging.main.SparqlRegexExtraction $@
